import javax.swing.table.AbstractTableModel;
/*
 *	===============================================================================
 *	TableModelAdapter.java : Defines data structures for holding the data to be presented by a JTable.
 *  YOUR UPI: xlad198
 *	=============================================================================== */
public class TableModelAdapter extends AbstractTableModel {
    private Shape nestedShape;

    TableModelAdapter(Shape nestedShape) {
        this.nestedShape = nestedShape;
    }

    private static String[] columnNames = {"Type", "X-pos", "Y-pos", "Width", "Height"};
    @Override
    public int getRowCount() {
        return ((NestedShape)this.nestedShape).getSize(); //must use casting since getSize() is only defined in NestedShape
    }

    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    public String getColumnName(int column) {
        return columnNames[column];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        if (columnIndex == 0) {
            return ((NestedShape)this.nestedShape).getShapeAt(rowIndex).getClass().getName();
        } else if (columnIndex == 1) {
            return ((NestedShape)this.nestedShape).getShapeAt(rowIndex).getX();
        }else if (columnIndex == 2) {
            return ((NestedShape)this.nestedShape).getShapeAt(rowIndex).getY();
        }else if (columnIndex == 3) {
            return ((NestedShape)this.nestedShape).getShapeAt(rowIndex).getWidth();
        }else {
            return ((NestedShape) this.nestedShape).getShapeAt(rowIndex).getHeight();
        }
    }

    public void setNestedShape(Shape s) {
        this.nestedShape = s;
    }
}
