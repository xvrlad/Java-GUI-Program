import java.awt.*;
import java.util.ArrayList;
import java.util.Arrays;

/*
 *	===============================================================================
 *	NestedShape.java : A shape that can have shapes inside it.
 *  YOUR UPI: xlad198
 *	=============================================================================== */
public class NestedShape extends RectangleShape {
    private ArrayList<Shape> nestedShapes = new ArrayList<Shape>();
    private static ShapeType nextShapeType = ShapeType.NESTED;

    NestedShape() {
        super();
    }
    NestedShape(int x, int y, int w, int h, int mw, int mh, Color bc, Color fc, PathType pt) {
        super(x, y, w, h, mw, mh, bc, fc, pt);
        nextShapeType = nextShapeType.next();
        createAddInnerShape(nextShapeType);
    }
    NestedShape(int x, int y, int w, int h, int mw, int mh, Color bc, Color fc, PathType pt, String text) {
        super(x, y, w, h, mw, mh, bc, fc, pt, text);
        nextShapeType = nextShapeType.next();
        createAddInnerShape(nextShapeType);
    }

    NestedShape(ArrayList<Shape> listOfShapes, Color fc, Color bc) {
        super(0, 0,DEFAULT_MARGIN_WIDTH, DEFAULT_MARGIN_HEIGHT, DEFAULT_MARGIN_WIDTH, DEFAULT_MARGIN_HEIGHT,bc, fc, PathType.BOUNCE,DEFAULT_TEXT);
        this.nestedShapes = listOfShapes;
    }

    public void createAddInnerShape(ShapeType st) {
        switch (st) {
            case RECTANGLE:
                RectangleShape newRect = new RectangleShape(0, 0, this.width / 2,
                        this.height / 2, this.width, this.height, this.borderColor,
                        this.fillColor, PathType.BOUNCE, this.text);
                newRect.setParent(this);
                this.nestedShapes.add(newRect);
                break;
            case XRECTANGLE:
                XRectangleShape newXRect = new XRectangleShape(0, 0, this.width / 2,
                        this.height / 2, this.width, this.height, this.borderColor,
                        this.fillColor, PathType.BOUNCE, this.text);
                newXRect.setParent(this);
                this.nestedShapes.add(newXRect);
                break;
            case NESTED:
                NestedShape newNested = new NestedShape(0, 0, this.width / 2,
                    this.height / 2, this.width, this.height, this.borderColor,
                    this.fillColor, PathType.BOUNCE, this.text);
                newNested.setParent(this);
                this.nestedShapes.add(newNested);
                break;
            case OVAL:
                OvalShape newOval = new OvalShape(0, 0, this.width / 2,
                        this.height / 2, this.width, this.height, this.borderColor,
                        this.fillColor, PathType.BOUNCE, this.text);
                newOval.setParent(this);
                this.nestedShapes.add(newOval);
                break;
            case SQUARE:
                SquareShape newSquare = new SquareShape(0, 0, Math.min(this.width / 2, this.height / 2), this.width, this.height, this.borderColor,
                        this.fillColor, PathType.BOUNCE, this.text);
                newSquare.setParent(this);
                this.nestedShapes.add(newSquare);
                break;
        }
    }
    public Shape getShapeAt(int index) {
        return this.nestedShapes.get(index);
    }
    public int getSize() {
        return this.nestedShapes.size();
    }
    public void draw(Painter painter) {
        this.setBorderColor(Color.black);
        painter.setPaint(borderColor);
        painter.drawRect(x, y, width, height);
        painter.translate(this.x, this.y);
        for (Shape shape : this.nestedShapes) {
            shape.draw(painter);
        }
        painter.translate(-this.x, -this.y);
    }

    @Override
    public void move() {
        super.move();
        for (Shape shape : this.nestedShapes) {
            shape.move();
        }
    }

    public void add(Shape s) {
        s.setParent(this);
        this.nestedShapes.add(s);
    }
    public void remove(Shape s) {
        s.setParent(null);
        this.nestedShapes.remove(s);
    }
    public int indexOf(Shape s) {
        return this.nestedShapes.indexOf(s);
    }
    public Shape[] getChildren() {
        return this.nestedShapes.toArray(new Shape[0]);
    }
}
