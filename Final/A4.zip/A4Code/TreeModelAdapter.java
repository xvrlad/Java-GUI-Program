import javax.swing.event.TreeModelEvent;
import javax.swing.event.TreeModelListener;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreePath;
import java.util.ArrayList;
import java.util.Arrays;

/*
 *	===============================================================================
 *	TreeModelAdapter.java : Lets the table model listen to the tree model.
 *  YOUR UPI: xlad198
 *	=============================================================================== */

public class TreeModelAdapter implements TreeModel {
    private Shape nestedShape = new NestedShape();
    private ArrayList<TreeModelListener> treeModelListeners = new ArrayList<TreeModelListener>();

    TreeModelAdapter(Shape nestedShape) {
        this.nestedShape = nestedShape;
    }

    @Override
    public Object getRoot() {
        return this.nestedShape;
    }

    @Override
    public Object getChild(Object parent, int index) {
        if (!(parent instanceof NestedShape) || index > ((NestedShape)parent).getSize()) {
            return null;
        }
        return ((NestedShape)parent).getShapeAt(index);
    }

    @Override
    public int getChildCount(Object parent) {
        if (!(parent instanceof NestedShape)) {
            return 0;
        }
        return ((NestedShape)parent).getSize();
    }

    @Override
    public boolean isLeaf(Object node) {
        return !(node instanceof NestedShape);
    }

    @Override
    public int getIndexOfChild(Object parent, Object child) {
        if (!(parent instanceof NestedShape)) {
            return -1;
        }
        return ((NestedShape)parent).indexOf((Shape) child);
    }
    @Override
    public void addTreeModelListener(final TreeModelListener modelListener) {
        this.treeModelListeners.add(modelListener);
    }
    @Override
    public void removeTreeModelListener(final TreeModelListener modelListener) {
        this.treeModelListeners.remove(modelListener);
    }

    public void fireTreeStructureChanged(final Object source, final Object[] path, final int[] childIndices, final Object[] children) {
        TreeModelEvent event = new TreeModelEvent(source, path, childIndices, children);
        for ( TreeModelListener l : this.treeModelListeners) {
            l.treeStructureChanged(event);
        }
    }

    public void fireTreeNodesInserted(Object source, Object[] path,int[] childIndices,Object[] children) {
        final TreeModelEvent event = new TreeModelEvent(source, path, childIndices, children);
        for (final TreeModelListener l : this.treeModelListeners) {
            l.treeNodesInserted(event);
        }
    }
    public void fireTreeNodesRemoved(Object source, Object[] path,int[] childIndices,Object[] children) {
        final TreeModelEvent event = new TreeModelEvent(source, path, childIndices, children);
        for (final TreeModelListener l : this.treeModelListeners) {
            l.treeNodesRemoved(event);
        }
    }

    public void addToRoot(Shape s) {
        ((NestedShape)this.nestedShape).add(s);
        s.setParent((NestedShape) this.nestedShape);
        fireTreeNodesInserted(this, new Object[]{this.nestedShape}, new int[]{((NestedShape) this.nestedShape).getSize()-1},new Object[]{s});
    }

    public boolean addNode(TreePath selectedPath, ShapeType currentShapeType) {
        Shape parent = (Shape) selectedPath.getLastPathComponent();
        if (!(parent instanceof NestedShape)) {
            return false;
        }
        int numberOfChildren = ((NestedShape)parent).getSize();
        ((NestedShape)parent).createAddInnerShape(currentShapeType);
        Shape child = ((NestedShape)parent).getShapeAt(numberOfChildren);
        fireTreeNodesInserted(this, selectedPath.getPath(), new int[]{numberOfChildren}, new Object[]{child});
        return true;
    }

    public boolean removeNodeFromParent(TreePath selectedPath) {
        if (selectedPath.getLastPathComponent() == this.nestedShape) {
            return false;
        }
        Shape child = (Shape) selectedPath.getLastPathComponent();
        NestedShape parent = child.getParent();
        int index = parent.indexOf(child);
        parent.remove(child);
        fireTreeNodesRemoved(this, selectedPath.getParentPath().getPath(), new int[]{index}, new Object[]{child});
        return true;
    }

    @Override
    public void valueForPathChanged(TreePath path, Object newValue) {}
    public void fireTreeNodesChanged(TreeModelEvent e) {}
}
